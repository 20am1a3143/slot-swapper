import express from "express";
import { PrismaClient } from "@prisma/client";
import { AuthRequest } from "../middleware/auth";

const prisma = new PrismaClient();
const router = express.Router();

// GET /api/events
router.get("/", async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const events = await prisma.event.findMany({ where: { ownerId: userId }, orderBy: { startTime: "asc" } });
  res.json(events);
});

// POST /api/events
router.post("/", async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const { title, startTime, endTime, status } = req.body;
  const ev = await prisma.event.create({ data: { title, startTime: new Date(startTime), endTime: new Date(endTime), status: status || "BUSY", ownerId: userId } });
  res.json(ev);
});

// PUT /api/events/:id
router.put("/:id", async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const id = req.params.id;
  const event = await prisma.event.findUnique({ where: { id } });
  if (!event || event.ownerId !== userId) return res.status(404).json({ message: "Not found or not yours" });
  const { title, startTime, endTime, status } = req.body;
  const updated = await prisma.event.update({ where: { id }, data: { title, startTime: startTime ? new Date(startTime) : undefined, endTime: endTime ? new Date(endTime) : undefined, status } });
  res.json(updated);
});

// DELETE /api/events/:id
router.delete("/:id", async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const id = req.params.id;
  const event = await prisma.event.findUnique({ where: { id } });
  if (!event || event.ownerId !== userId) return res.status(404).json({ message: "Not found or not yours" });
  await prisma.event.delete({ where: { id } });
  res.json({ success: true });
});

export default router;

