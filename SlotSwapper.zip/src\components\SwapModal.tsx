import React from "react";
import { apiFetch } from "../api";
import { useAuth } from "../auth/AuthProvider";

export default function SwapModal({ theirSlot, myOptions, onClose, onRequested }: any) {
  const { token } = useAuth();
  const [selectedMySlot, setSelectedMySlot] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);

  async function submit() {
    if (!selectedMySlot) return alert("choose your slot to offer");
    setLoading(true);
    try {
      await apiFetch("/swap-request", token, {
        method: "POST",
        body: JSON.stringify({ mySlotId: selectedMySlot, theirSlotId: theirSlot.id }),
      });
      onRequested();
    } catch (err: any) {
      alert(err.message || "Failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal">
      <h3>Request swap for: {theirSlot.title} ({new Date(theirSlot.startTime).toLocaleString()})</h3>
      <div>
        <h4>Your swappable slots</h4>
        <ul>
          {myOptions.map((m: any) => (
            <li key={m.id}>
              <label>
                <input type="radio" name="mySlot" value={m.id} onChange={() => setSelectedMySlot(m.id)} />
                {m.title} — {new Date(m.startTime).toLocaleString()}
              </label>
            </li>
          ))}
        </ul>
      </div>
      <button onClick={submit} disabled={loading}>Send Request</button>
      <button onClick={onClose}>Cancel</button>
    </div>
  );
}

