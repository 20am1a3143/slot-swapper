import express from "express";
import { PrismaClient } from "@prisma/client";
import { AuthRequest } from "../middleware/auth";

const prisma = new PrismaClient();
const router = express.Router();

// GET /api/swappable-slots
router.get("/swappable-slots", async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const events = await prisma.event.findMany({
    where: { status: "SWAPPABLE", ownerId: { not: userId } },
    orderBy: { startTime: "asc" }
  });
  res.json(events);
});

// POST /api/swap-request
router.post("/swap-request", async (req: AuthRequest, res) => {
  const requesterId = req.user!.id;
  const { mySlotId, theirSlotId } = req.body as { mySlotId: string; theirSlotId: string };

  const my = await prisma.event.findUnique({ where: { id: mySlotId } });
  const their = await prisma.event.findUnique({ where: { id: theirSlotId } });
  if (!my || !their) return res.status(400).json({ message: "Invalid slot ids" });
  if (my.ownerId !== requesterId) return res.status(403).json({ message: "Not your slot" });
  if (my.status !== "SWAPPABLE" || their.status !== "SWAPPABLE") return res.status(400).json({ message: "Both must be swappable" });

  const swapReq = await prisma.swapRequest.create({
    data: {
      offeredSlotId: my.id,
      targetSlotId: their.id,
      requesterId,
      responderId: their.ownerId,
    },
  });

  await prisma.event.update({ where: { id: my.id }, data: { status: "SWAP_PENDING" } });
  await prisma.event.update({ where: { id: their.id }, data: { status: "SWAP_PENDING" } });

  res.json({ swapReq });
});

// POST /api/swap-response/:requestId
router.post("/swap-response/:requestId", async (req: AuthRequest, res) => {
  const responderId = req.user!.id;
  const { requestId } = req.params;
  const { accept } = req.body as { accept: boolean };

  const sr = await prisma.swapRequest.findUnique({ where: { id: requestId }, include: { offeredSlot: true, targetSlot: true } });
  if (!sr) return res.status(404).json({ message: "Not found" });
  if (sr.responderId !== responderId) return res.status(403).json({ message: "Not authorized" });

  if (!accept) {
    await prisma.swapRequest.update({ where: { id: sr.id }, data: { status: "REJECTED" } });
    await prisma.event.update({ where: { id: sr.offeredSlotId }, data: { status: "SWAPPABLE" } });
    await prisma.event.update({ where: { id: sr.targetSlotId }, data: { status: "SWAPPABLE" } });
    return res.json({ success: true });
  }

  // accept: swap owners
  await prisma.$transaction(async (tx) => {
    const offered = await tx.event.findUnique({ where: { id: sr.offeredSlotId } });
    const target = await tx.event.findUnique({ where: { id: sr.targetSlotId } });
    if (!offered || !target) throw new Error("Missing events");

    await tx.event.update({ where: { id: offered.id }, data: { ownerId: target.ownerId, status: "BUSY" } });
    await tx.event.update({ where: { id: target.id }, data: { ownerId: offered.ownerId, status: "BUSY" } });
    await tx.swapRequest.update({ where: { id: sr.id }, data: { status: "ACCEPTED" } });
  });

  res.json({ success: true });
});

// GET /api/swap-requests
router.get("/swap-requests", async (req: AuthRequest, res) => {
  const userId = req.user!.id;
  const baseInclude = {
    offeredSlot: true,
    targetSlot: true,
    requester: { select: { id: true, name: true, email: true } },
    responder: { select: { id: true, name: true, email: true } },
  } as const;

  const [incoming, outgoing] = await Promise.all([
    prisma.swapRequest.findMany({
      where: { responderId: userId },
      include: baseInclude,
      orderBy: { createdAt: "desc" },
    }),
    prisma.swapRequest.findMany({
      where: { requesterId: userId },
      include: baseInclude,
      orderBy: { createdAt: "desc" },
    }),
  ]);

  res.json({ incoming, outgoing });
});

export default router;

