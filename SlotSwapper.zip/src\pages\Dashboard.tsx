import React, { useEffect, useState } from "react";
import { apiFetch } from "../api";
import { useAuth } from "../auth/AuthProvider";
import EventCard from "../components/EventCard";

export default function Dashboard() {
  const { token } = useAuth();
  const [events, setEvents] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");

  async function load() {
    const list = await apiFetch("/events", token);
    setEvents(list);
  }

  useEffect(() => { load(); }, [token]);

  async function createEvent() {
    await apiFetch("/events", token, {
      method: "POST",
      body: JSON.stringify({ title, startTime, endTime, status: "SWAPPABLE" })
    });
    setTitle(""); setStartTime(""); setEndTime("");
    await load();
  }

  return (
    <div>
      <h2>Your Events</h2>
      <div style={{ display: "grid", gap: 8 }}>
        {events.map((e) => (
          <EventCard key={e.id} event={e} onChanged={load} />
        ))}
      </div>
      <h3>Create Event</h3>
      <div>
        <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
        <input type="datetime-local" value={startTime} onChange={e=>setStartTime(e.target.value)} />
        <input type="datetime-local" value={endTime} onChange={e=>setEndTime(e.target.value)} />
        <button onClick={createEvent}>Add</button>
      </div>
    </div>
  );
}

