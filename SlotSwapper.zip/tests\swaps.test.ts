import request from "supertest";
import app from "../src/server";

describe("Swap flow", () => {
  let tokenA: string, tokenB: string;
  let evA1: any, evB1: any;
  let swapReqId: string;

  beforeAll(async () => {
    const resA = await request(app).post("/api/auth/signup").send({ name: "A", email: "a@test", password: "pass" });
    tokenA = resA.body.token;
    const resB = await request(app).post("/api/auth/signup").send({ name: "B", email: "b@test", password: "pass" });
    tokenB = resB.body.token;

    evA1 = (await request(app).post("/api/events").set("Authorization", `Bearer ${tokenA}`).send({ title: "A1", startTime: new Date(), endTime: new Date(Date.now()+3600000), status: "SWAPPABLE" })).body;
    evB1 = (await request(app).post("/api/events").set("Authorization", `Bearer ${tokenB}`).send({ title: "B1", startTime: new Date(), endTime: new Date(Date.now()+3600000), status: "SWAPPABLE" })).body;
  });

  it("creates swap request and sets both to SWAP_PENDING", async () => {
    const res = await request(app).post("/api/swap-request").set("Authorization", `Bearer ${tokenA}`).send({ mySlotId: evA1.id, theirSlotId: evB1.id });
    expect(res.status).toBe(200);
    swapReqId = res.body.swapReq.id;

    const aEvent = (await request(app).get("/api/events").set("Authorization", `Bearer ${tokenA}`)).body.find((e:any) => e.id === evA1.id);
    const bEvent = (await request(app).get("/api/events").set("Authorization", `Bearer ${tokenB}`)).body.find((e:any) => e.id === evB1.id);
    expect(aEvent.status).toBe("SWAP_PENDING");
    expect(bEvent.status).toBe("SWAP_PENDING");
  });

  it("accepts swap and swaps owners", async () => {
    const res = await request(app).post(`/api/swap-response/${swapReqId}`).set("Authorization", `Bearer ${tokenB}`).send({ accept: true });
    expect(res.status).toBe(200);

    const aEvents = (await request(app).get("/api/events").set("Authorization", `Bearer ${tokenA}`)).body;
    const bEvents = (await request(app).get("/api/events").set("Authorization", `Bearer ${tokenB}`)).body;

    expect(aEvents.find((e:any) => e.title === "B1")).toBeDefined();
    expect(bEvents.find((e:any) => e.title === "A1")).toBeDefined();
  });
});

