# SlotSwapper

SlotSwapper is a peer‑to‑peer time‑slot scheduling app. Users mark their own events as SWAPPABLE, discover other users’ swappable slots, request a swap, and accept/reject incoming requests. On acceptance, the two event owners are exchanged transactionally.

## Tech Stack
- Backend: Node.js, Express, TypeScript, Prisma, SQLite (for quick local setup)
- Frontend: React (Vite, TypeScript, React Router)
- Auth: JWT (Bearer token)
- Tests: Jest + Supertest (backend)

## Repository Structure
```
backend/
  src/
    middleware/
    routes/
    server.ts
  prisma/
    schema.prisma
  tests/
    swaps.test.ts
  package.json
frontend/
  src/
    auth/
    components/
    pages/
    api.ts
    App.tsx
    main.tsx
  index.html
  package.json
```

## Local Setup (Step‑by‑Step)
Follow exactly; no external DB required.

1) Backend – install deps
```
cd backend
npm install
```

2) Database & Prisma
- Using SQLite (file: `backend/prisma/dev.db`), no env needed for DB.
- Apply schema and generate client:
```
npx prisma migrate dev --name init
npx prisma generate
```

3) Run backend
```
npm run dev
```
- Server: http://localhost:4000
- API base: http://localhost:4000/api

4) Frontend – install & run
```
cd ../frontend
npm install
npm run dev
```
- App will print a dev URL (typically http://localhost:5173)
- If your backend runs elsewhere, create `frontend/.env` with:
```
VITE_API_URL=http://localhost:4000/api
```

5) Tests (optional)
```
cd ../backend
npm test
```

## Authentication
- Signup and login return `{ token, user }`.
- Send `Authorization: Bearer <token>` on protected endpoints.

## API Endpoints

### Auth
| Method | Path              | Body                                 | Response                     |
|-------:|-------------------|--------------------------------------|------------------------------|
| POST   | /api/auth/signup  | { name, email, password }            | { token, user }              |
| POST   | /api/auth/login   | { email, password }                  | { token, user }              |

### Events (current authenticated user)
| Method | Path             | Body                                                                 | Notes |
|-------:|------------------|----------------------------------------------------------------------|-------|
| GET    | /api/events      | —                                                                    | List your events |
| POST   | /api/events      | { title, startTime, endTime, status? }                               | `status` defaults to "BUSY" |
| PUT    | /api/events/:id  | { title?, startTime?, endTime?, status? }                            | Must own the event |
| DELETE | /api/events/:id  | —                                                                    | Must own the event |

Event fields: `id`, `title`, `startTime`, `endTime`, `status` ("BUSY" | "SWAPPABLE" | "SWAP_PENDING"), `ownerId`.

### Swaps
| Method | Path                            | Body                                          | Response / Behavior |
|-------:|----------------------------------|-----------------------------------------------|---------------------|
| GET    | /api/swappable-slots            | —                                             | Swappable slots not owned by the caller |
| POST   | /api/swap-request               | { mySlotId, theirSlotId }                     | Creates PENDING request; sets both events to SWAP_PENDING |
| POST   | /api/swap-response/:requestId   | { accept: boolean }                           | Accept: swap owners and set both to BUSY; Reject: set both back to SWAPPABLE |
| GET    | /api/swap-requests              | —                                             | { incoming, outgoing } including related users and slots |

### Example cURL
```
# Signup
curl -X POST http://localhost:4000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"A","email":"a@test","password":"pass"}'

# Create a SWAPPABLE event
curl -X POST http://localhost:4000/api/events \
  -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" \
  -d '{"title":"Focus","startTime":"2025-11-05T10:00:00.000Z","endTime":"2025-11-05T11:00:00.000Z","status":"SWAPPABLE"}'

# Request a swap
curl -X POST http://localhost:4000/api/swap-request \
  -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" \
  -d '{"mySlotId":"EV_A","theirSlotId":"EV_B"}'

# Accept a swap
curl -X POST http://localhost:4000/api/swap-response/REQUEST_ID \
  -H "Authorization: Bearer TOKEN_B" -H "Content-Type: application/json" \
  -d '{"accept":true}'
```

## Frontend Overview
- Protected routes for Dashboard, Marketplace, and Requests.
- `AuthProvider` stores `{ token, user }` in localStorage and injects JWT on API calls.
- Marketplace pulls `GET /api/swappable-slots` and opens a modal to choose your offered slot.
- Requests page shows `incoming` and `outgoing`, with Accept/Reject actions.
- State updates after actions to reflect current statuses without manual refresh.

## Design Choices & Assumptions
- SQLite chosen for quick local evaluation; can switch to Postgres by changing `datasource` in `prisma/schema.prisma` and setting `DATABASE_URL`.
- Event status stored as string for broad DB compatibility (SQLite).
- Owner swap is executed in a transaction to keep data consistent.
- No real‑time layer included by default; pages refresh their view after actions.

## Challenges
- Ensuring transactional integrity for owner swaps and restoring statuses on rejection.
- Balancing speed of local setup with a structure that still maps cleanly to production DBs.

## Deployment (Optional)
- Not included here. Can deploy frontend (Vercel/Netlify) and backend (Render/Fly/Heroku) easily; add `VITE_API_URL` for the frontend to point to the deployed API.
