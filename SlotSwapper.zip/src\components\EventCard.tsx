import React from "react";
import { apiFetch } from "../api";
import { useAuth } from "../auth/AuthProvider";

export default function EventCard({ event, onChanged }: { event: any; onChanged: () => void }) {
  const { token } = useAuth();

  async function toggleStatus() {
    const status = event.status === "SWAPPABLE" ? "BUSY" : "SWAPPABLE";
    await apiFetch(`/events/${event.id}`, token, {
      method: "PUT",
      body: JSON.stringify({ status })
    });
    onChanged();
  }

  async function remove() {
    await apiFetch(`/events/${event.id}`, token, { method: "DELETE" });
    onChanged();
  }

  return (
    <div style={{ border: "1px solid #ccc", padding: 8, borderRadius: 6 }}>
      <div><strong>{event.title}</strong></div>
      <div>{new Date(event.startTime).toLocaleString()} - {new Date(event.endTime).toLocaleString()}</div>
      <div>Status: {event.status}</div>
      <button onClick={toggleStatus}>
        {event.status === "SWAPPABLE" ? "Mark BUSY" : "Mark SWAPPABLE"}
      </button>
      <button onClick={remove}>Delete</button>
    </div>
  );
}

