import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import authRouter from "./routes/auth";
import eventsRouter from "./routes/events";
import swapsRouter from "./routes/swaps";
import { authMiddleware } from "./middleware/auth";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth", authRouter);
app.use("/api/events", authMiddleware, eventsRouter);
app.use("/api", authMiddleware, swapsRouter);

const port = process.env.PORT || 4000;

if (process.env.NODE_ENV !== "test") {
  app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`Server listening on http://localhost:${port}`);
  });
}

export default app;

