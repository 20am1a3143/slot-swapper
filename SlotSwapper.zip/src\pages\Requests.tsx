import React, { useEffect, useState } from "react";
import { apiFetch } from "../api";
import { useAuth } from "../auth/AuthProvider";

export default function Requests() {
  const { token } = useAuth();
  const [incoming, setIncoming] = useState<any[]>([]);
  const [outgoing, setOutgoing] = useState<any[]>([]);

  async function load() {
    const data = await apiFetch("/swap-requests", token);
    setIncoming(data.incoming);
    setOutgoing(data.outgoing);
  }

  useEffect(() => { load(); }, [token]);

  async function respond(id: string, accept: boolean) {
    await apiFetch(`/swap-response/${id}`, token, { method: "POST", body: JSON.stringify({ accept }) });
    await load();
  }

  return (
    <div>
      <h3>Incoming Requests</h3>
      {incoming.map(r => (
        <div key={r.id}>
          <div>From: {r.requester.name} offering {r.offeredSlot.title} 
            → your {r.targetSlot.title}</div>
          <button onClick={() => respond(r.id, true)}>Accept</button>
          <button onClick={() => respond(r.id, false)}>Reject</button>
        </div>
      ))}

      <h3>Outgoing Requests</h3>
      {outgoing.map(r => (
        <div key={r.id}>{r.targetSlot.title} — Status: {r.status}</div>
      ))}
    </div>
  );
}

