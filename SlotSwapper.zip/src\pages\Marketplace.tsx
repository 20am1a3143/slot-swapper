import React, { useEffect, useState } from "react";
import { apiFetch } from "../api";
import { useAuth } from "../auth/AuthProvider";
import SwapModal from "../components/SwapModal";

export default function Marketplace() {
  const { token } = useAuth();
  const [list, setList] = useState<any[]>([]);
  const [modalSlot, setModalSlot] = useState<any | null>(null);
  const [mySwappable, setMySwappable] = useState<any[]>([]);

  async function load() {
    const data = await apiFetch("/swappable-slots", token);
    setList(data);
    const mine = await apiFetch("/events", token);
    setMySwappable(mine.filter((e: any) => e.status === "SWAPPABLE"));
  }

  useEffect(() => { load(); }, [token]);

  return (
    <div>
      <h2>Marketplace</h2>
      <ul>
        {list.map((e) => (
          <li key={e.id}>
            {e.title} — {new Date(e.startTime).toLocaleString()}
            <button onClick={() => setModalSlot(e)}>Request Swap</button>
          </li>
        ))}
      </ul>
      {modalSlot && (
        <SwapModal
          theirSlot={modalSlot}
          myOptions={mySwappable}
          onRequested={() => { setModalSlot(null); load(); }}
          onClose={() => setModalSlot(null)}
        />
      )}
    </div>
  );
}

