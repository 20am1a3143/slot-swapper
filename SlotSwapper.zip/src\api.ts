const API_ROOT = (import.meta as any).env?.VITE_API_URL || "http://localhost:4000/api";

export async function apiFetch(path: string, token?: string | null, opts: any = {}) {
  const headers: any = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${API_ROOT}${path}`, { ...opts, headers });
  if (res.status === 401) throw new Error("Unauthorized");
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || "API error");
  return json;
}

